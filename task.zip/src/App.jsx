import React from 'react';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div className="min-h-screen flex-col justify-center ">
      <Dashboard />
    </div>
  );
}

export default App;
