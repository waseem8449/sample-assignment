import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFlag as ffa} from '@fortawesome/free-regular-svg-icons';
import { faFlag } from '@fortawesome/free-solid-svg-icons';

const Table = () => {
    // console.log('data', data)
    const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:3000/api1');
        const jsonData = await response.json();
        setData(jsonData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full border-collapse border border-gray-300">
        <thead>
          <tr className=''>
            <th className="border border-gray-300 bg-slate-800 text-white px-4 py-2">Task</th>
            <th className="border border-gray-300 bg-slate-800 text-white px-4 py-2">Expiry_date</th>
            <th className="border border-gray-300 bg-slate-800 text-white px-4 py-2">User</th>
            {/* Display the flag icon */}
            <th className="border border-gray-300 bg-slate-800 text-white px-4 py-2"> <FontAwesomeIcon icon={faFlag} size="lg" /><br></br>Impotant</th>
            <th className="border border-gray-300 bg-slate-800 text-white px-4 py-2">Action</th>

          </tr>
        </thead>
        <tbody>
          {data.Tasks.map((item, index) => (
            <tr key={index} className={index % 2 === 0 ? 'bg-gray-100' : ''}>
              <td className="border border-gray-300 px-4 py-2">{item.Task}</td>
              <td className="border border-gray-300 px-4 py-2">{item.Expiry_date}</td>
              <td className="border border-gray-300 px-4 py-2">{item.User}</td>
              <td className="border border-gray-300 px-4 py-2">{item.Impotant? <FontAwesomeIcon icon={ffa} size="lg" />:<FontAwesomeIcon icon={faFlag} size="lg" />}</td>
              <td className="border border-gray-300 px-4 py-2">-</td>

            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
