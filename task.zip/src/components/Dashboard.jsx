import React, { useState } from 'react';
import { data } from "../data"
import Table from './Table';

const Dashboard = () => {
    const [textInput, setTextInput] = useState('');
    const [selectedDate, setSelectedDate] = useState('');
    const [selectedOption, setSelectedOption] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        // You can perform any desired actions with the form data here
        console.log('Text Input:', textInput);
        console.log('Selected Date:', selectedDate);
        console.log('Selected Option:', selectedOption);
    };

    return (
        <div className="p-6 border-4 border-grey-200">
            <h2 className="text-xl font-semibold mb-4">User Task</h2>
            <form onSubmit={handleSubmit}>
                <div className='flex mt-0 justify-around'>
                    <div className="mb-4">
                        <input
                            type="text"
                            id="text-input"
                            placeholder='Task description'
                            className="w-full border rounded px-3 py-2 focus:outline-none focus:border-blue-500"
                            value={textInput}
                            onChange={(e) => setTextInput(e.target.value)}
                        />
                        <label htmlFor="text-input" className="block font-medium mb-1">
                            Task
                        </label>
                    </div>
                    <div className="mb-4">
                        <input
                            type="date"
                            id="date-input"
                            placeholder='12-2-2022'

                            className="w-full border rounded px-3 py-2 focus:outline-none focus:border-blue-500"
                            value={selectedDate}
                            onChange={(e) => setSelectedDate(e.target.value)}
                        />
                        <label htmlFor="date-input" className="block font-medium mb-1">
                            Expiry  Date
                        </label>
                    </div>
                    <div className="mb-4">
                        <select
                            id="select-input"
                            className="w-full border rounded px-3 py-2 focus:outline-none focus:border-blue-500"
                            value={selectedOption}
                            onChange={(e) => setSelectedOption(e.target.value)}
                        >
                            <option value="">Select an option</option>
                            <option value="option1">{data.Users[0].name}</option>
                            <option value="option2">{data.Users[1].name}</option>
                            <option value="option3">{data.Users[2].name}</option>
                        </select>
                        <label htmlFor="select-input" className="block font-medium mb-1">
                            User
                        </label>
                    </div>
                    <button
                        type="submit"
                        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                    >
                        Submit
                    </button>
                </div>
            </form>
            <Table />

        </div>
    );
};

export default Dashboard;
